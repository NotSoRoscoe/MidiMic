#ifndef MIDITRANSLATE_H
#define MIDITRANSLATE_H

	extern int rangeSize;
	extern int minMidi;
	int getMidiVal(float freq);

#endif
